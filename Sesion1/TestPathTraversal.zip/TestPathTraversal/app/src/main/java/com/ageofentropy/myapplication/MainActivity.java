package com.ageofentropy.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends AppCompatActivity {


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGenerateMemo = findViewById(R.id.btnGenerateMemo);
        btnGenerateMemo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(
                        MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        23);

                // Storing the data in file with name as geeksData.txt
                InputStream input = getResources().openRawResource(R.raw.example);

                File targetFile = new File(Environment.getExternalStorageDirectory().toString() + "/Download/example.zip");

                try {
                    java.nio.file.Files.copy(input, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        Button btnLoadMemo = findViewById(R.id.btnLoadMemo);
        btnLoadMemo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(
                        MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        23);
                checkFiles();
                unpackZip("/storage/emulated/0/Download/", "example.zip");

            }
        });

        Button btnSharedPrefs = findViewById(R.id.btnShowSharedPrefs);
        btnSharedPrefs.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                SharedPreferences sharedPrefs = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                String message = sharedPrefs.getString("name", "");
                int subscriptors = sharedPrefs.getInt("subscriptors", 0);

                TextView txtMessage = findViewById(R.id.sample_text);
                txtMessage.setText("Message from Age Of Entropy: " + message + "\n# Subscriptors: " + subscriptors);
            }
        });

        Button btnReloadSharedPrefs = findViewById(R.id.btnReloadSharedPrefs);
        btnReloadSharedPrefs.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);

                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putString("name", "Thanks for the subscription on Age of Entropy!!");
                myEdit.putInt("subscriptors", 225);

                myEdit.commit();
            }
        });
    }

    private static void checkFiles() {
        File fmd = new File("/data/data/com.ageofentropy.myapplication/files/");
        if (!fmd.exists()) {
            fmd.mkdirs();
        }
    }
    private static boolean unpackZip(String path, String zipname)
    {
        InputStream is;
        ZipInputStream zis;
        try
        {
            String filename;
            is = new FileInputStream(path + zipname);
            zis = new ZipInputStream(new BufferedInputStream(is));
            ZipEntry ze;
            byte[] buffer = new byte[1024];
            int count;

            while ((ze = zis.getNextEntry()) != null)
            {
                filename = ze.getName();
                // Need to create directories if not exists, or
                // it will generate an Exception...
                if (ze.isDirectory()) {
                    File fmd = new File("/data/data/com.ageofentropy.myapplication/files/" + filename);
                    fmd.mkdirs();
                    continue;
                }

                FileOutputStream fout = new FileOutputStream("/data/data/com.ageofentropy.myapplication/files/" + filename);
                while ((count = zis.read(buffer)) != -1)
                {
                    fout.write(buffer, 0, count);
                }
                fout.close();
                zis.closeEntry();
            }
            zis.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }
}